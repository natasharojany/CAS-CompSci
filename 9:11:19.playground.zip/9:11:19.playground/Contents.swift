func Square(math: Int) -> Int {
    let number = math * math
    return(number)
}
print(Square(math:9))

func five()-> Int {
    return 5
}
print(five())

func fullName(first: String, last: String) -> String{
    return first + " " + last
}
print(fullName(first: "Tashi", last: "Rojany"))

func Shout(input: String) -> String{
    return input + "!"
}
print(Shout(input: "Hello"))



func numberName(num: Int) -> String! {
    let letters = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]
    if num <= 9 {
    return letters[num]
    }
    else {
    return nil
}
}
    print(numberName(num:5))
